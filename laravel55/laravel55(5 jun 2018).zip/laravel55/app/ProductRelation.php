<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductRelation extends Model
{
      protected $fillable = ['product_id','relation_id'];
}
