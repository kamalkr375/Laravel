<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductLocationProduct extends Model
{
    public $timestamps = false;
	protected $fillable = ['product_location_id','product_id'];
	
	
	
	
	
	
	
}
